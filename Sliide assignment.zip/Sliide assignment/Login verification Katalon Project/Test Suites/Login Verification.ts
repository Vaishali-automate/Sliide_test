<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Login Verification</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>10</pageLoadTimeout>
   <pageLoadTimeoutDefault>false</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>3358125b-2feb-4563-abf9-19fd56c8906f</testSuiteGuid>
   <testCaseLink>
      <guid>6cd4f43a-ad24-44f4-b527-2d99c35dcc2b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/1- Invalid Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b2c1be1a-a8ae-46ac-a894-4015a896077c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/2- Valid Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>61b6e8d5-a19d-40e4-93bd-1a187323da48</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/3- Verify landing screen</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
